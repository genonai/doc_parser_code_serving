from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any, ClassVar, Dict, List, Literal, Optional, Union

from pydantic import (
    AnyUrl,
    BaseModel,
    ConfigDict,
    Field,
)
from typing_extensions import deprecated

from docling.datamodel import asr_model_specs

# Import the following for backwards compatibility
from docling.datamodel.accelerator_options import AcceleratorDevice, AcceleratorOptions
from docling.datamodel.layout_model_specs import (
    DOCLING_LAYOUT_EGRET_LARGE,
    DOCLING_LAYOUT_EGRET_MEDIUM,
    DOCLING_LAYOUT_EGRET_XLARGE,
    DOCLING_LAYOUT_HERON,
    DOCLING_LAYOUT_HERON_101,
    DOCLING_LAYOUT_V2,
    LayoutModelConfig,
)
from docling.datamodel.pipeline_options_asr_model import (
    InlineAsrOptions,
)
from docling.datamodel.pipeline_options_vlm_model import (
    ApiVlmOptions,
    InferenceFramework,
    InlineVlmOptions,
    ResponseFormat,
)
from docling.datamodel.vlm_model_specs import (
    GRANITE_VISION_OLLAMA as granite_vision_vlm_ollama_conversion_options,
    GRANITE_VISION_TRANSFORMERS as granite_vision_vlm_conversion_options,
    SMOLDOCLING_MLX as smoldocling_vlm_mlx_conversion_options,
    SMOLDOCLING_TRANSFORMERS as smoldocling_vlm_conversion_options,
    VlmModelType,
)

class BaseOptions(BaseModel):
    """Base class for options."""

    kind: ClassVar[str]


class TableStructureModelType(str, Enum):
    """Enum of valid table structure model types."""

    TABLEFORMER = "tableformer"
    VLM = "vlm"
    DOTSOCR = "dotsocr"


class LayoutModelType(str, Enum):
    """Enum of valid layout model types."""

    DOCLING_LAYOUT = "docling_layout"
    GENOS_LAYOUT = "genos_layout"


class TableFormerMode(str, Enum):
    """Modes for the TableFormer model."""

    FAST = "fast"
    ACCURATE = "accurate"


class VlmTableStructureOptions(BaseModel):
    """Options for VLM-based table structure recognition via external API."""

    url: AnyUrl = AnyUrl("http://localhost:8000/v1/chat/completions")
    api_key: Optional[str] = None
    model: Optional[str] = None
    headers: Dict[str, str] = {}
    params: Dict[str, Any] = {}
    timeout: float = 60
    prompt: str = ""
    scale: float = 2.0
    temperature: float = 0.0
    concurrency: int = 1
    use_ocr_in_prompt: bool = True
    prompt_bbox_scale: int = 1024


class TableStructureOptions(BaseModel):
    """Options for table structure model selection and configuration."""

    table_structure_model_type: TableStructureModelType = (
        TableStructureModelType.DOTSOCR
    )
    do_cell_matching: bool = (
        True
        # True:  Matches predictions back to PDF cells. Can break table output if PDF cells
        #        are merged across table columns.
        # False: Let table structure model define the text cells, ignore PDF cells.
    )
    mode: TableFormerMode = TableFormerMode.ACCURATE
    vlm_table_structure_options: VlmTableStructureOptions = (
        VlmTableStructureOptions()
    )


class OcrOptions(BaseOptions):
    """OCR options."""

    lang: List[str]
    force_full_page_ocr: bool = False  # If enabled a full page OCR is always applied
    bitmap_area_threshold: float = (
        0.05  # percentage of the area for a bitmap to processed with OCR
    )


class RapidOcrOptions(OcrOptions):
    """Options for the RapidOCR engine."""

    kind: ClassVar[Literal["rapidocr"]] = "rapidocr"

    # English and chinese are the most commly used models and have been tested with RapidOCR.
    lang: List[str] = [
        "english",
        "chinese",
    ]
    # However, language as a parameter is not supported by rapidocr yet
    # and hence changing this options doesn't affect anything.

    # For more details on supported languages by RapidOCR visit
    # https://rapidai.github.io/RapidOCRDocs/blog/2022/09/28/%E6%94%AF%E6%8C%81%E8%AF%86%E5%88%AB%E8%AF%AD%E8%A8%80/

    # For more details on the following options visit
    # https://rapidai.github.io/RapidOCRDocs/install_usage/api/RapidOCR/

    text_score: float = 0.5  # same default as rapidocr

    use_det: Optional[bool] = None  # same default as rapidocr
    use_cls: Optional[bool] = None  # same default as rapidocr
    use_rec: Optional[bool] = None  # same default as rapidocr

    print_verbose: bool = False  # same default as rapidocr

    det_model_path: Optional[str] = None  # same default as rapidocr
    cls_model_path: Optional[str] = None  # same default as rapidocr
    rec_model_path: Optional[str] = None  # same default as rapidocr
    rec_keys_path: Optional[str] = None  # same default as rapidocr

    model_config = ConfigDict(
        extra="forbid",
    )


class PaddleOcrOptions(OcrOptions):
    """Options for the PaddleOCR engine."""

    kind: ClassVar[Literal["paddleocr"]] = "paddleocr"

    # lang: List[str] = [
    #     "korean"
    # ]

    text_score: float = 0.5

    # use_doc_orientation_classify: Optional[bool]=False
    # use_doc_unwarping: Optional[bool]=False
    # use_textline_orientation: Optional[bool]=False

    # det_model_dir: Optional[str] = None
    # det_model_name: Optional[str] = None
    # rec_model_dir: Optional[str] = None
    # rec_model_name: Optional[str] = None

    model_config = ConfigDict(
        extra="forbid",
    )

    ocr_endpoint: str = ""
    timeout: int = 60  # seconds


class UpstageOcrOptions(OcrOptions):
    """Options for the Upstage Document Digitization OCR API."""

    kind: ClassVar[Literal["upstage"]] = "upstage"

    lang: List[str] = ["ko", "en"]

    api_endpoint: str = "https://api.upstage.ai/v1/document-digitization"
    model: str = "ocr"
    api_key: str = ""
    timeout: int = 60  # seconds
    text_score: float = 0.5

    model_config = ConfigDict(
        extra="forbid",
    )


class EasyOcrOptions(OcrOptions):
    """Options for the EasyOCR engine."""

    kind: ClassVar[Literal["easyocr"]] = "easyocr"
    lang: List[str] = ["fr", "de", "es", "en"]

    use_gpu: Optional[bool] = None

    confidence_threshold: float = 0.5

    model_storage_directory: Optional[str] = None
    recog_network: Optional[str] = "standard"
    download_enabled: bool = True

    model_config = ConfigDict(
        extra="forbid",
        protected_namespaces=(),
    )


class TesseractCliOcrOptions(OcrOptions):
    """Options for the TesseractCli engine."""

    kind: ClassVar[Literal["tesseract"]] = "tesseract"
    lang: List[str] = ["fra", "deu", "spa", "eng"]
    tesseract_cmd: str = "tesseract"
    path: Optional[str] = None

    model_config = ConfigDict(
        extra="forbid",
    )


class TesseractOcrOptions(OcrOptions):
    """Options for the Tesseract engine."""

    kind: ClassVar[Literal["tesserocr"]] = "tesserocr"
    lang: List[str] = ["fra", "deu", "spa", "eng"]
    path: Optional[str] = None

    model_config = ConfigDict(
        extra="forbid",
    )


class OcrMacOptions(OcrOptions):
    """Options for the Mac OCR engine."""

    kind: ClassVar[Literal["ocrmac"]] = "ocrmac"
    lang: List[str] = ["fr-FR", "de-DE", "es-ES", "en-US"]
    recognition: str = "accurate"
    framework: str = "vision"

    model_config = ConfigDict(
        extra="forbid",
    )


class PictureDescriptionBaseOptions(BaseOptions):
    batch_size: int = 8
    scale: float = 2

    picture_area_threshold: float = (
        0.05  # percentage of the area for a picture to processed with the models
    )


class PictureDescriptionApiOptions(PictureDescriptionBaseOptions):
    kind: ClassVar[Literal["api"]] = "api"

    url: AnyUrl = AnyUrl("http://localhost:8000/v1/chat/completions")
    headers: Dict[str, str] = {}
    params: Dict[str, Any] = {}
    timeout: float = 20
    concurrency: int = 1

    prompt: str = "Describe this image in a few sentences."
    provenance: str = ""


class PictureDescriptionVlmOptions(PictureDescriptionBaseOptions):
    kind: ClassVar[Literal["vlm"]] = "vlm"

    repo_id: str
    prompt: str = "Describe this image in a few sentences."
    # Config from here https://huggingface.co/docs/transformers/en/main_classes/text_generation#transformers.GenerationConfig
    generation_config: Dict[str, Any] = dict(max_new_tokens=200, do_sample=False)

    @property
    def repo_cache_folder(self) -> str:
        return self.repo_id.replace("/", "--")


# SmolVLM
smolvlm_picture_description = PictureDescriptionVlmOptions(
    repo_id="HuggingFaceTB/SmolVLM-256M-Instruct"
)

# GraniteVision
granite_picture_description = PictureDescriptionVlmOptions(
    repo_id="ibm-granite/granite-vision-3.2-2b-preview",
    prompt="What is shown in this image?",
)


# Define an enum for the backend options
class PdfBackend(str, Enum):
    """Enum of valid PDF backends."""

    PYPDFIUM2 = "pypdfium2"
    DLPARSE_V1 = "dlparse_v1"
    DLPARSE_V2 = "dlparse_v2"
    DLPARSE_V4 = "dlparse_v4"


# Define an enum for the ocr engines
@deprecated("Use ocr_factory.registered_enum")
class OcrEngine(str, Enum):
    """Enum of valid OCR engines."""

    EASYOCR = "easyocr"
    TESSERACT_CLI = "tesseract_cli"
    TESSERACT = "tesseract"
    OCRMAC = "ocrmac"
    RAPIDOCR = "rapidocr"


class HwpToPdfBackend(str, Enum):
    """HWP → PDF 변환 백엔드 식별자 (이슈 #199)."""

    PDF_SDK = "pdf_sdk"
    RHWP = "rhwp"
    LIBREOFFICE = "libreoffice"


class PipelineOptions(BaseModel):
    """Base pipeline options."""

    create_legacy_output: bool = (
        True  # This default will be set to False on a future version of docling
    )
    document_timeout: Optional[float] = None
    accelerator_options: AcceleratorOptions = AcceleratorOptions()
    enable_remote_services: bool = False
    allow_external_plugins: bool = False
    save_images: bool = True
    include_wmf: bool = False
    dump_sdk_output: bool = False

    # HWP → PDF 변환 backend 선택 (이슈 #199).
    # 미지정 시 환경의 availability 기반으로 자동 chain 구성됨.
    # 환경변수 (HWP_TO_PDF_PRIMARY / HWP_TO_PDF_ORDER / HWP_TO_PDF_DISABLE_FALLBACK) 도
    # 동일 의미로 동작하며, env 와 본 옵션 중 명시적으로 지정된 쪽이 우선이다.
    hwp_to_pdf_primary: Optional[HwpToPdfBackend] = None
    hwp_to_pdf_order: Optional[List[HwpToPdfBackend]] = None
    hwp_to_pdf_disable_fallback: bool = False


class PaginatedPipelineOptions(PipelineOptions):
    artifacts_path: Optional[Union[Path, str]] = None

    images_scale: float = 1.0
    generate_page_images: bool = False
    generate_picture_images: bool = False


class VlmPipelineOptions(PaginatedPipelineOptions):
    generate_page_images: bool = True
    force_backend_text: bool = (
        False  # (To be used with vlms, or other generative models)
    )
    # If True, text from backend will be used instead of generated text
    vlm_options: Union[InlineVlmOptions, ApiVlmOptions] = (
        smoldocling_vlm_conversion_options
    )


class BaseLayoutOptions(BaseOptions):
    """Base options for layout models."""

    keep_empty_clusters: bool = (
        False  # Whether to keep clusters that contain no text cells
    )
    skip_cell_assignment: bool = (
        False  # Skip cell-to-cluster assignment for VLM-only processing
    )


class GenosLayoutOptions(BaseModel):
    """Options specific to Genos layout inference."""

    endpoint: str = None
    api_key: str = ""
    model: str = "dots-mocr"
    max_completion_tokens: int = 16384
    # per-request 타임아웃(초). 3600 은 과도 → 1200(20분)으로 축소.
    # 큐 대기 시간까지 포함되므로 너무 짧으면 정상 다(多)페이지 문서가 죽을 수 있어
    # 500~600 은 위험. 출력 잘림은 max_completion_tokens 가 정하지 timeout 이 아님.
    timeout: int = 1200
    # Retries on transient transport failures (429/502/503/504, connection errors).
    # A runaway response (finish_reason == "length") or a read timeout is NOT retried - the
    # same prompt would run away again, so those fall back to layout_only instead (#278).
    retry_count: int = 2
    # Retry policy hook. When set, the VLM call is run through this callable so the host
    # application decides what counts as transient and how long to wait.
    # Signature: (send: Callable[[], T], *, retries: int) -> T
    # Left unset, the call runs once exactly as before.
    retry_runner: Optional[Any] = None
    temperature: float = 0.1
    top_p: float = 0.9
    repetition_penalty: float = 1.15  # >1.0 to suppress VLM token-repetition degeneration
    # 폭주(timeout/length) 감지 시 layout_only 보정 on/off
    length_fallback_enabled: bool = True
    # 보정 시 페이지 재렌더 DPI (dots.ocr 권장 200, 상한 11,289,600px)
    fallback_dpi: int = 200
    # dotsocr 가 표 HTML 을 못 준 빈 테이블을 TableFormer 로 채울지 (CPU ~1.7s/표)
    table_fallback_enabled: bool = True


class LayoutOptions(BaseLayoutOptions):
    """Options for layout processing."""

    layout_model_type: LayoutModelType = LayoutModelType.DOCLING_LAYOUT
    create_orphan_clusters: bool = True  # Whether to create clusters for orphaned cells
    visualize_layout_side_by_side: bool = (
        False  # Debug only: render layout visualization in split left/right panes
    )
    genos_layout_options: GenosLayoutOptions = GenosLayoutOptions()
    model_spec: LayoutModelConfig = DOCLING_LAYOUT_V2


class AsrPipelineOptions(PipelineOptions):
    asr_options: Union[InlineAsrOptions] = asr_model_specs.WHISPER_TINY
    artifacts_path: Optional[Union[Path, str]] = None


class PdfPipelineOptions(PaginatedPipelineOptions):
    """Options for the PDF pipeline."""

    # 페이지 묶음 크기. None 이면 프로세스 전역 settings.perf.page_batch_size 를 쓴다.
    # 프로세서마다 다른 값을 가질 수 있게 옵션으로 둔다(genon #481).
    page_batch_size: Optional[int] = None
    do_table_structure: bool = True  # True: perform table structure extraction
    do_ocr: bool = True  # True: perform OCR, replace programmatic PDF text
    do_code_enrichment: bool = False  # True: perform code OCR
    do_formula_enrichment: bool = False  # True: perform formula OCR, return Latex code
    do_picture_classification: bool = False  # True: classify pictures in documents
    do_picture_description: bool = False  # True: run describe pictures in documents
    force_backend_text: bool = (
        False  # (To be used with vlms, or other generative models)
    )
    # If True, text from backend will be used instead of generated text

    table_structure_options: TableStructureOptions = TableStructureOptions()
    ocr_options: OcrOptions = EasyOcrOptions()
    picture_description_options: PictureDescriptionBaseOptions = (
        smolvlm_picture_description
    )
    layout_options: LayoutOptions = LayoutOptions()

    images_scale: float = 1.0
    generate_page_images: bool = False
    generate_picture_images: bool = False
    generate_table_images: bool = Field(
        default=False,
        deprecated=(
            "Field `generate_table_images` is deprecated. "
            "To obtain table images, set `PdfPipelineOptions.generate_page_images = True` "
            "before conversion and then use the `TableItem.get_image` function."
        ),
    )

    generate_parsed_pages: Literal[True] = (
        True  # Always True since parsed_page is now mandatory
    )


class ProcessingPipeline(str, Enum):
    STANDARD = "standard"
    VLM = "vlm"
    ASR = "asr"


# ADD CUSTOM PIPELINE OPTION


class DataEnrichmentOptions(BaseModel):
    """Data enrichment options for metadata extraction and other enrichment features."""

    # TOC enrichment options
    do_toc_enrichment: bool = False
    toc_doc_type: Optional[str] = None  # e.g., "normal"(default), "law"
    toc_system_prompt: Optional[str] = None
    toc_user_prompt: Optional[str] = None
    # TOC API configuration options
    toc_api_provider: Optional[str] = None  # e.g., "openrouter", "openai", "custom"
    toc_api_key: Optional[str] = None
    toc_api_base_url: Optional[str] = None
    toc_model: Optional[str] = None
    toc_temperature: Optional[float] = None
    toc_top_p: Optional[float] = None
    toc_seed: Optional[int] = None
    toc_max_tokens: Optional[int] = None
    toc_repetition_penalty: Optional[float] = None  # >1.0 suppresses repetition/degeneration loops
    # Thinking(reasoning) mode. Default "off" (send the disable token).
    # thinking: "off"|"on"|"auto", dialect: "standard"(enable_thinking) | "hcx"(force/skip_reasoning)
    # Use "auto" to send nothing (let the model decide).
    toc_thinking: Optional[str] = "off"
    toc_thinking_dialect: str = "standard"
    # Extra request parameters merged into the payload verbatim. This has to live here rather
    # than in the transport hook because the LLM cache key is (url, payload) - a sender that
    # mutated the payload would let two different settings share one cache entry.
    toc_params: Optional[Dict[str, Any]] = None
    # Transport hook. When set, PromptManager hands the finished request to this callable
    # instead of posting it itself, so the host application owns headers, timeout, retry and
    # response handling while docling keeps deciding what to ask. Per category because the
    # connection settings (key, headers, timeout) differ between TOC and metadata.
    # Signature: (url: str, payload: dict, headers: dict) -> Optional[str]
    # Left unset, the built-in requests path runs exactly as before.
    toc_chat_sender: Optional[Any] = None
    # Preflight prompt-token guard options (TOC)
    toc_precheck_enabled: Optional[bool] = None
    toc_max_context_tokens: Optional[int] = None
    toc_completion_reserved_tokens: Optional[int] = None
    # Split (carry-over refine) TOC extraction options.
    # When enabled, the document is split into page-based chunks (N pages each) and
    # extracted sequentially, carrying the accumulated outline forward into each
    # subsequent chunk's prompt. This is an explicit mode toggle (not an overflow fallback).
    toc_split_enabled: Optional[bool] = None
    toc_pages_per_chunk: Optional[int] = None
    toc_page_overlap: Optional[int] = None
    toc_carryover_max_tokens: Optional[int] = None

    # Metadata extraction options
    extract_metadata: bool = False
    metadata_system_prompt: Optional[str] = None
    metadata_user_prompt: Optional[str] = None
    # Metadata API configuration options
    metadata_api_provider: Optional[str] = (
        None  # e.g., "openrouter", "openai", "custom"
    )
    metadata_api_key: Optional[str] = None
    metadata_api_base_url: Optional[str] = None
    metadata_model: Optional[str] = None
    metadata_temperature: Optional[float] = None
    metadata_top_p: Optional[float] = None
    metadata_seed: Optional[int] = None
    metadata_max_tokens: Optional[int] = None
    # Thinking(reasoning) mode. Default "off" (send the disable token). "auto" = send nothing.
    metadata_thinking: Optional[str] = "off"
    metadata_thinking_dialect: str = "standard"
    # Extra request parameters merged into the payload verbatim (see toc_params).
    metadata_params: Optional[Dict[str, Any]] = None
    metadata_chat_sender: Optional[Any] = None  # see toc_chat_sender
    # Preflight prompt-token guard options (Metadata)
    metadata_precheck_enabled: Optional[bool] = None
    metadata_max_context_tokens: Optional[int] = None
    metadata_completion_reserved_tokens: Optional[int] = None
